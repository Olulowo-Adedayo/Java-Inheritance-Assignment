public class Dayo extends Computer_Science{
    String student_name;
    public void department(){
       student_name="Olulowo Adedayo Samuel";
       Reg_No = 2302899;
       Matric_No = "23CD010307";
        System.out.println("Student Name: " + student_name);
        System.out.println("Reg No: " + Reg_No);
        System.out.println("Matric No: " + Matric_No);
    }
}
