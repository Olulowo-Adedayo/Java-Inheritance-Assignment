public class Student_2 {
    String Matric_No;
    int Reg_No;
    public void student_details(){
        System.out.println("Student Info Here:");
    }
}
