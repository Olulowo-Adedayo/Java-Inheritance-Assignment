public class Main {
    public static void main(String[] args) {



        Dayo obj = new Dayo();

        obj.student_details();
        obj.department();
        obj.student_college();


    }
}
