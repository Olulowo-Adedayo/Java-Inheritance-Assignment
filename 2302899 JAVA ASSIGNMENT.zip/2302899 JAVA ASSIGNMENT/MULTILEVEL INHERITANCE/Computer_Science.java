public class Computer_Science extends Student_2{
    String college;
    String Department;
    public void student_college(){
        college= "CPAS";
        Department = "Computer Science";
        System.out.println("College: " + college);
        System.out.println("Department: " + Department);
    }

}
