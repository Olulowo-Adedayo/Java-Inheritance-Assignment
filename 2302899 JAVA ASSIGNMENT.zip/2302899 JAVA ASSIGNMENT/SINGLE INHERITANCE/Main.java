public class Main {
    public static void main(String[] args) {


        STUDENT obj2 = new STUDENT();

        obj2.student_details();

        obj2.student();
    }
}
