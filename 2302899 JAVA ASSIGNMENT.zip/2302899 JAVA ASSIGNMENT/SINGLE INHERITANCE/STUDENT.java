public class STUDENT extends Student_info {
    public void student(){
        student_name= "Kenechukwu Goodluck";
        Reg_No = 2302292;
        Matric_No = "23CF010222";
        College = "CPAS";
        Department = "Mathematics";
        System.out.println("Name: " + student_name);
        System.out.println("Reg No: " + Reg_No);
        System.out.println("Matric No: " + Matric_No);
        System.out.println("College: " + College);
        System.out.println("Department: " + Department);

    }


}
