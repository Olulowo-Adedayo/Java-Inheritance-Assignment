public class Student_info {
    String student_name;
    int Reg_No;
    String Matric_No;
    String College;
    String Department;

    public void student_details (){
        System.out.println("Student Info: ");
    }
}
