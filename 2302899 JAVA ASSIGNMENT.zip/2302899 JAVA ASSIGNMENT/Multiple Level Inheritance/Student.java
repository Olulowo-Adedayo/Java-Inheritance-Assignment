public class Student extends COLLEGE,DEPARTMENT{
    String name;
    int reg_no;
    String matric_no;
    public void student_detail(){
        name = "Olulowo Adedayo";
        reg_no = 2302899;
        matric_no ="23CD010307";
        college = "CPAS";
        this.department = "Computer Science";
        System.out.println(CPAS);


    }
}
