public class DEPARTMENT {
    String department;
    public void department(){
        System.out.println("Department");
    }
}
