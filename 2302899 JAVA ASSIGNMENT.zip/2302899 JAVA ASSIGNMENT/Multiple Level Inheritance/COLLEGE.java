public class COLLEGE {
    String college;
    public void college_name(){
        System.out.println("College: ");
    }
}
