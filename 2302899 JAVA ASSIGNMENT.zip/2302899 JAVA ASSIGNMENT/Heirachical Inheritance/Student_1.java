public class Student_1 extends COMPUTERSCIENCE{

    public void student1_info(){
       student_name = "Dayo";
       Reg_No = 2302899;
       Matric_No = "23CD010307";

        System.out.println("Student Name: " + student_name );
        System.out.println("Reg No: " + Reg_No);
        System.out.println("Matric No: " + Matric_No);
        System.out.println("College: " + College);
        System.out.println("Department: " + Department);

    }

}
