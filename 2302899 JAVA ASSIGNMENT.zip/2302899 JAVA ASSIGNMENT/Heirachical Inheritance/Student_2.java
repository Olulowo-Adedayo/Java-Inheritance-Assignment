public class Student_2 extends COMPUTERSCIENCE{

    public void student2_info(){
        student_name = "Celestine";
        Reg_No = 2301010;
        Matric_No = "23CD010023";

        System.out.println("Student Name: " + student_name );
        System.out.println("Reg No: " + Reg_No);
        System.out.println("Matric No: " + Matric_No);
        System.out.println("College: " + College);
        System.out.println("Department: " + Department);


    }
}



