public class COMPUTERSCIENCE {
    String student_name;
    int Reg_No;
    String Matric_No;
    String College = "CPAS";
    String Department = "Computer Science";


    public void student_details(){
        System.out.println("STUDENT INFO");


    }
}
